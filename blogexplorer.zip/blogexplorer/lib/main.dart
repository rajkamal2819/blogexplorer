import 'package:blogexplorer/networking.dart';
import 'package:flutter/material.dart';
import 'model.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Blog App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: BlogListScreen(),
    );
  }
}

class BlogListScreen extends StatefulWidget {
  @override
  _BlogListScreenState createState() => _BlogListScreenState();
}

class _BlogListScreenState extends State<BlogListScreen> {
  late Future<BlogList> blogList;

  @override
  void initState() {
    super.initState();
    blogList = NetworkRequest.fetchBlogs();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Blog List'),
      ),
      body: FutureBuilder<BlogList>(
        future: blogList,
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            final list = snapshot.data?.blogs;
            return ListView.builder(
              itemCount: 20,
              itemBuilder: (context, index) {
                return GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => DetailedBlogScreen(list[index]),
                      ),
                    );
                  },
                  child: Card(
                    elevation: 5,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: Column(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(15),
                            topRight: Radius.circular(15),
                          ),
                          child: Image.network(
                            list![index].imageUrl!,
                            height: 200,
                            width: double.infinity,
                            fit: BoxFit.cover,
                          ),
                        ),
                        Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [Colors.transparent, Colors.black.withOpacity(0.7)],
                            ),
                            borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(15),
                              topRight: Radius.circular(15),
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.all(16),
                          child: Text(
                            list![index].title!,
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 18,
                              color: Colors.black45,
                            ),
                          ),
                        ),
                      ],
                    ),
                  )

                );
              },
            );
          }
          return CircularProgressIndicator();
        },
      ),
    );
  }
}

class DetailedBlogScreen extends StatelessWidget {
  final Blog list;
  DetailedBlogScreen(this.list);

  // Define properties to receive blog data

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Blog Detail"),
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(
                height: 20.0, // Add some spacing between the title and image
              ),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 16.0), // Add side margins to the text
                child: Text(
                  list.title!,
                  style: TextStyle(
                    fontSize: 24.0,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ), // Display the blog title with larger text and bold, centered horizontally
              SizedBox(
                height: 10.0, // Add some spacing between the title and image
              ),
              SizedBox(
                width: 300, // Adjust the width of the image as needed
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(12.0),
                  child: Image.network(
                    list.imageUrl!,
                    fit: BoxFit.cover,
                  ),
                ),
              ), // Display the blog image with rounded corners and proper aspect ratio, centered horizontally
              SizedBox(
                height: 10.0, // Add some spacing between the image and description
              ),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 16.0), // Add side margins to the description
                child: Text(
                  "In the small town of Hawkins, Indiana, strange occurrences unfold when a young "
                      "boy mysteriously disappears. His friends embark on a quest to find him and "
                      "uncover a series of supernatural events, government conspiracies, and a"
                      " parallel dimension known as the Upside Down. "
                      "Stranger Things is a nostalgic journey back to the '80s filled"
                      " with thrilling mysteries and a group of endearing kids.\n\n"
                      "Stranger Things is a nostalgic journey back to the '80s filled"
                      " with thrilling mysteries and a group of endearing kids.\n\n"
                      "Explore the life of Queen Elizabeth II as The Crown takes"
                      " you through the reign of the British monarch. This critically "
                      "acclaimed series delves into the political and personal challenges"
                      " faced by the Queen and her family as they navigate the turbulent waters of the 20th century. "
                      "With stunning performances and exquisite production, it's a royal drama of epic proportions.",
                  style: TextStyle(
                    fontSize: 16.0,
                    color: Colors.black87,
                  ),
                ),
              ), // Display the description text below the image
              SizedBox(
                height: 20.0, // Add some spacing between the description and the end of the screen
              ),
            ],
          ),
        ),
      ),


    );
  }
}
